import { supabase } from '../supabaseClient'

/**
 * Fetch close price for a single stock from Yahoo Finance
 */
async function fetchCloseFromYahoo(symbol) {
  const yahooSymbol = symbol.includes('.') ? symbol : `${symbol}.NS`
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${yahooSymbol}?range=5d&interval=1d`

  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } })
  if (!res.ok) {
    throw new Error(`Yahoo Finance request failed for ${yahooSymbol}: ${res.status}`)
  }

  const json = await res.json()
  const result = json?.chart?.result?.[0]
  if (!result) throw new Error(`No chart data returned for ${yahooSymbol}`)

  const timestamps = result.timestamp
  const closes = result.indicators?.quote?.[0]?.close
  if (!timestamps || !closes) throw new Error(`Malformed chart data for ${yahooSymbol}`)

  // Find the most recent valid close price
  for (let i = timestamps.length - 1; i >= 0; i--) {
    if (closes[i] != null) {
      const date = new Date(timestamps[i] * 1000).toISOString().slice(0, 10)
      return { date, close: Math.round(closes[i] * 100) / 100 }
    }
  }
  throw new Error(`No valid close price found for ${yahooSymbol}`)
}

/**
 * Fetch and update prices for all active stocks
 * Called from Dashboard "Refresh Prices" button
 */
export async function refreshPrices() {
  try {
    // Get current user's active stocks
    const { data: stocks, error: stockError } = await supabase
      .from('stocks')
      .select('id, symbol')
      .eq('status', 'active')

    if (stockError) throw new Error(`Failed to fetch stocks: ${stockError.message}`)
    if (!stocks || stocks.length === 0) {
      return { success: true, message: 'No active stocks to update', count: 0 }
    }

    // Fetch prices for all stocks in parallel
    const results = await Promise.allSettled(
      stocks.map(async (stock) => {
        const { date, close } = await fetchCloseFromYahoo(stock.symbol)

        // Upsert price to database
        const { error: upsertError } = await supabase
          .from('daily_prices')
          .upsert(
            { stock_id: stock.id, date, close_price: close },
            { onConflict: 'stock_id,date' }
          )

        if (upsertError) throw new Error(`Failed to save ${stock.symbol}: ${upsertError.message}`)
        return { symbol: stock.symbol, date, close }
      })
    )

    // Check for failures
    const failed = results.filter((r) => r.status === 'rejected')
    const succeeded = results.filter((r) => r.status === 'fulfilled')

    if (failed.length > 0) {
      const errors = failed.map((r) => r.reason.message).join('; ')
      throw new Error(`Partial failure: ${errors}`)
    }

    return {
      success: true,
      message: `Updated prices for ${succeeded.length} stock(s)`,
      count: succeeded.length,
      stocks: succeeded.map((r) => r.value),
    }
  } catch (err) {
    console.error('Price refresh error:', err)
    throw new Error(err.message || 'Failed to refresh prices')
  }
}
